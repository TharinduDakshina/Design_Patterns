package cretional_patterns.factory;

public interface Shape {
    void draw();
}
