package cretional_patterns.Builder;

public class Wapper implements Packing{
    @Override
    public String pack() {
        return "Wapper";
    }
}
