package cretional_patterns.Builder;

public interface Packing {
    public String pack();
}
