package cretional_patterns.abstractFactory;

public interface Shape {
    void draw();
}
