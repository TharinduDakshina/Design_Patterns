package cretional_patterns.abstractFactory;

public interface Colour {
    void fill();
}
