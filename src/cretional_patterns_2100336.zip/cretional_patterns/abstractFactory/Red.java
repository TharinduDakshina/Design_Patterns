package cretional_patterns.abstractFactory;

public class Red implements Colour{
    @Override
    public void fill() {
        System.out.println("Red:fill()");
    }
}
